﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PharmacyMedicineSupplyService.Models
{
    public class PharmacyDTO
    {
        public string pharmacyName { get; set; }
    }
}
