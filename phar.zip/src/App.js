import logo from './logo.svg';
import './App.css';
import React from "react";
import { Login } from "./Pages/Login";

import { Route, Routes } from "react-router-dom";
import { Homepage } from "./Pages/HomePage";

import { NavbarPage } from "./components/Navbar";
import Medicine from "./Pages/Medicine";
import Contact from "./Pages/Contact";
import BookSchedule from "./Pages/BookSchedule";
import Medicinedemand from "./Pages/Medicinedemand";
import HomePagedata from "./Pages/Homepagedata";

function App() {
  return (
    <div className="App">
      <NavbarPage />
      <Routes>
        <Route path="/" element={<Homepage />} />
        <Route path="/login" element={<Login />} />
        <Route path="/medicine" element={<Medicine />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/bookSchedule" element={<BookSchedule />} />
        <Route path="/medicinedemand" element={<Medicinedemand />} />
        <Route path="/home" element={<HomePagedata />} />
      </Routes>
    </div>
  );
}

export default App;
