import React from "react";
import { Navigate, useNavigate } from "react-router-dom";
// import { AuthContext } from "./AuthContext";
import { Container, Row, Col, Form } from "react-bootstrap";
import image from "../images/How-to-Become-a-Pharmacist.jpg"

export const Login = () => {
    const [formData, setData] = React.useState({
        userID: undefined,
        username: "",
        password: "",

    });

    let { userID, username, password } = formData;


    const navigate = useNavigate();
    // console.log(auth);

    async function fetchData(props) {
        console.log(formData)
        const requestOptions = {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                userID: Number(userID),
                userName: username,
                password: password,
            }),
        };
        console.log(requestOptions.body)
        await fetch("https://localhost:44300/User/Login", requestOptions)
            .then((res) => res.json())
            .then((response) => {
                console.log("1", response);
                
                if (response.status && response.status === 400) {
                    console.log("'",response)
                }
                else {
                    console.log(response)
                    localStorage.setItem("access", response.token);
                    // sessionStorage.setItem("access", response.data);
                    localStorage.setItem("isLoggedIn", true);

                    if (localStorage.getItem("isLoggedIn") === "true") {
                        navigate("/");
                    }
                }
            })
            .catch((err) => console.log(err));
    }

    const handelSubmit = (e) => {
        e.preventDefault();

        fetchData();
    };

    if (localStorage.getItem("isLoggedIn") === "true") {
        console.log(localStorage.getItem("isLoggedIn"));
        return <Navigate to="/" />;
    }

    return (
        <React.Fragment>
            <main className="mt-3 d-flex justify-content-center align-items-center">
                
                <Container> 
                
                    <Row>
                        <Col md={6}>
                            <img src={image} className="img-fluid"/>
                        </Col>
                        <Col md={6}>
                        <h3>Sign In to your Account!</h3>
                            <Form onSubmit={(e) => handelSubmit(e)}>
                                <Form.Group className="mb-3">
                                    
                                    {/* <Form.Label htmlFor="username">User ID</Form.Label> */}
                                    <Form.Control
                                        type={"number"}
                                        name="userID"
                                        id="userID"
                                        value={userID}
                                        placeholder="Enter UserId"
                                        onChange={(e) =>
                                            setData({ ...formData, [e.target.name]: e.target.value })
                                        }
                                    />
                                </Form.Group>
                                <Form.Group className="mb-3">
                                    {/* <Form.Label htmlFor="username">Username</Form.Label> */}
                                    <Form.Control
                                        type={"text"}
                                        name="username"
                                        id="username"
                                        value={username}
                                        placeholder="Enter User Name"
                                        onChange={(e) =>
                                            setData({ ...formData, [e.target.name]: e.target.value })
                                        }
                                    />
                                </Form.Group>
                                <Form.Group className="mb-3">
                                    {/* <Form.Label htmlFor="password">Password</Form.Label> */}
                                    <Form.Control
                                        type={"password"}
                                        name="password"
                                        id="password"
                                        value={password}
                                        placeholder="Password"
                                        onChange={(e) =>
                                            setData({ ...formData, [e.target.name]: e.target.value })
                                        }
                                    />
                                </Form.Group>

                                <Form.Group>
                                    <Form.Control type={"submit"} value="Submit" className="btn btn-primary" />
                                </Form.Group>
                            </Form>
                        </Col>
                        
                    </Row>
                </Container>
            </main>
        </React.Fragment>
    );
};
