import React from "react";
import { Table } from "react-bootstrap";
import { Navigate } from "react-router-dom";

function Medicine() {


  const [medicine, setMedicine] = React.useState(null);

  const fetchData = async () => {
    await fetch("https://localhost:44394/MedicineStockInformation")
      .then(res => res.json())
      .then(response => {
        console.log(response);
        setMedicine(response)
      });
  }

  React.useEffect(() => {
    fetchData();
  }, [])


  return (
    <>
      {localStorage.getItem("isLoggedIn") === "true" ? (
        <>
          {medicine != null ? (<>
            <Table striped bordered hover>
              <thead>
                <tr>
                  <th>S.No</th>
                  <th>Medicine Name</th>
                  <th>TargetAilment</th>
                  <th>Stock Available</th>
                  <th>Date Of Expiriy</th>
                  <th>Chemical Compostion</th>
                </tr>
              </thead>
              <tbody>
                {medicine.map((data, index) => (
                  <tr>
                    <td>{index + 1}</td>
                    <td>{data.name}</td>
                    <td>{data.targetAilment}</td>
                    <td>{data.numberOfTabletsInStock}</td>
                    <td>{data.dateOfExpiry}</td>
                    <td>{data.chemicalComposition.map((chemical, index) => (
                      <li>{chemical}</li>
                    ))}</td>
                  </tr>
                ))}

              </tbody>
            </Table></>) : (<p>Data loading</p>)}
        </>
      ) : (
        <Navigate to="/login" />
      )}
    </>
  )
}


export default Medicine
