import {Table} from "react-bootstrap";

function Contact() {

    return(
        <Table striped bordered hover>
  <thead>
    <tr>
      <th>S.No</th>
      <th>Name</th>
      <th>EMail</th>
      <th>Phone</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>1</td>
      <td>Vineeth Gowtham</td>
      <td>Vineeth@gmail.com</td>
      <td>9843846647</td>
    </tr>
    <tr>
      <td>2</td>
      <td>Vaishnavi</td>
      <td>Vaishnavi@gmail.com</td>
      <td>987654331</td>
    </tr>
    <tr>
      <td>3</td>
      <td>Anusha</td>
      <td>Anusha@gmail.com</td>
      <td>987654331</td>
    </tr>
    <tr>
      <td>4</td>
      <td>Priyavandhana Kumari</td>
      <td>Priya@gmail.com</td>
      <td>987654331</td>
    </tr>
    
  </tbody>
</Table>
    )
}


export default Contact
