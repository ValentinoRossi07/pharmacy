import React from 'react';
import { Card, Button, Col } from "react-bootstrap";
import {Link} from "react-router-dom"
import image from "../images/airport-guide-medical-facilities.jpg";
import image1 from "../images/contact-us.png";
import image2 from "../images/medcinestcok.jpg";
import image3 from "../images/doctorschedule.jpg";
import image4 from "../images/medicinedemand.jpg";

function Homepagedata() {
    return (

        <>
            <Col md={4}>
                <Card style={{ width: '18rem' }}>
                    <Card.Img variant="top" src={image1} />
                    <Card.Body>
                        <Card.Title>Contact Us</Card.Title>
                        <Card.Text>
                        If you face any issues and concerns with our services.
                        
                        </Card.Text>
                        <Link to="/contact" class="btn btn-primary">Contact</Link>
                    </Card.Body>
                </Card>
            </Col>
            <Col md={4}>
            <Card style={{ width: '18rem' }}>
                    <Card.Img variant="top" src={image2} style={{ height:'126px'}} />
                    <Card.Body>
                        <Card.Title>Medicine Stock</Card.Title>
                        <Card.Text>
                            List of Medicine Available
                        </Card.Text>
                        <Link to="/medicine" class="btn btn-primary">Medcine Stock</Link>
                    </Card.Body>
                </Card>
            </Col>
            <Col md={4}>
            <Card style={{ width: '18rem' }}>
                    <Card.Img variant="top" src={image3} style={{ height:'126px'}} />
                    <Card.Body>
                        <Card.Title>Book Schedule</Card.Title>
                        <Card.Text>
                            Check details of doctor.
                        </Card.Text>
                        <Link to="/bookSchedule" className='btn btn-primary'>Book Schedule</Link>
                    </Card.Body>
                </Card>
                <br/>
            </Col>
            <br />
            <hr/>
            <Col md={4}>
            <Card style={{ width: '18rem' }}>
                    <Card.Img variant="top" src={image4} />
                    <Card.Body>
                        <Card.Title>Medicine Demand</Card.Title>
                        <Card.Text>
                            Medicine Demand
                        </Card.Text>
                        <Link to="/medicinedemand" className='btn btn-primary'>Medicine Demand</Link>
                    </Card.Body>
                </Card>
            </Col>
        </>

    )
}

export default Homepagedata;