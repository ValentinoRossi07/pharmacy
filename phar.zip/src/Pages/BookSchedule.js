import React from 'react';
import { Container, Row, Form, Card, Button, Col, Table } from "react-bootstrap";
import { Link, Navigate, useNavigate } from "react-router-dom";
import axios from "axios";




function BookSchedule() {


    const [schedule, setSchedule] = React.useState({
        date: null
    });

    const [meetingList, setMeetingList] = React.useState({
        data: null
    })

    const [show, setShow] = React.useState(false);


    const navigate = useNavigate();


    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const { data } = await axios.get(
                `https://localhost:44369/RepSchedule?startDate=${schedule.date}`,
                {
                    headers: {
                        Authorization: `Bearer ${localStorage.getItem("access")}`,
                    },
                }
            );
            console.log(data);
            setMeetingList({ data });
            setShow(true);
        } catch (err) {
            console.log(err);
            if (err.response.status === 401) {
                localStorage.removeItem("access");
                localStorage.setItem("isLoggedIn", false);
                navigate("/login");
            }
        }
    };

    return (
        <React.Fragment>
            {localStorage.getItem("isLoggedIn") === "true" ? (
                <main className="mt-3">
                    <Container>
                        <Row>
                            <Col md={4}>
                                <Form onSubmit={(e) => handleSubmit(e)}>
                                    <Form.Group className="mb-3">
                                        <Form.Control
                                            type="date"
                                            value={schedule.date}
                                            onChange={(e) =>
                                                setSchedule((prevState) => ({
                                                    ...prevState,
                                                    date: e.target.value,
                                                }))
                                            }
                                            required
                                        />
                                    </Form.Group>
                                    <Button type="submit">Proceed</Button>
                                </Form>
                            </Col>
                        </Row>

                        {show ? (
                            <>
                                <Row className="mt-4">
                                    <Col md={12}>
                                        <Table striped bordered hover>
                                            <thead>
                                                <tr>
                                                    <th>S.No</th>
                                                    <th>Representative Name</th>
                                                    <th>Treating Ailment</th>
                                                    <th>Doctor Name</th>
                                                    <th>Medicine</th>
                                                    <th>Meeting Slot</th>
                                                    <th>Date of Meeting</th>
                                                    <th>Contact Number</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {meetingList.data && meetingList.data.map((data, index) => (
                                                    <tr>
                                                        <td>{index + 1}</td>
                                                        <td>{data.repName}</td>
                                                        <td>{data.treatingAilment}</td>
                                                        <td>{data.doctorName}</td>
                                                        <td>{data.medicine}</td>
                                                        <td>{data.meetingSlot}</td>
                                                        <td>{data.dateOfMeeting}</td>
                                                        <td>{data.doctorContactNumber}</td>
                                                    </tr>
                                                ))}

                                            </tbody>
                                        </Table>
                                    </Col>
                                </Row>
                            </>
                        ) : (
                            ""
                        )}
                    </Container>
                </main>
            ) : (
                <Navigate to="/login" />
            )}
        </React.Fragment>
    )
}

export default BookSchedule;