import React from 'react';
import { Form, Table, Button, Row, Col } from "react-bootstrap";

import axios from 'axios';
import { useNavigate } from 'react-router-dom';

function Medicinedemand() {

    const navigate = useNavigate()

    const initialState = [
        {
            medicineName: "Oxytocin",
            count: 0
        },
        {
            medicineName: "Ibuprofen",
            count: 0
        },
        {
            medicineName: "Aceclofenac",
            count: 0
        },
        {
            medicineName: "Ibuprofin",
            count: 0
        },
        {
            medicineName: "Pracetamol",
            count: 0
        },
    ]

    const [medicineDemand, setMedicineDemand] = React.useState(initialState);

    const [show, setShow] = React.useState(false);

    const [pharmacyDetails, setPharmacyDetails] = React.useState({ data: null });

    const handleChange = (e) => {
        e.preventDefault();
        console.log(e.target.value)
        setMedicineDemand(prevState => {
            const newState = prevState.map(obj => {
                // 👇️ if id equals 2, update country property
                if (obj.medicineName === e.target.name) {
                    return { ...obj, count: obj.count++ };
                }

                // 👇️ otherwise return object as is
                return obj;
            });

            return newState;
        })
    }


    const handleSubmit = async (e) => {
        e.preventDefault();
        console.log(medicineDemand)

        const body = JSON.stringify(medicineDemand)

        try {
            const { data, response } = await axios.post(
                `https://localhost:44377/api/PharmacySupply/Get`, body,
                {
                    headers: {
                        Authorization: `Bearer ${localStorage.getItem("access")}`,
                        "Content-Type": "application/json"
                    },
                }
            );
            // console.log(response);
            setPharmacyDetails({data});
            setShow(true)
            console.log(pharmacyDetails)

        } catch (err) {
            console.log(err);
            if (err.response.status === 404) {
                alert(err.response.data)
            }
            if (err.response.status === 401) {
                localStorage.removeItem("access");
                localStorage.setItem("isLoggedIn", false);
                navigate("/login");
            }
        }
    }



    return (
        <>
            <Form onSubmit={(e) => handleSubmit(e)}>
                <Table>
                    <thead>
                        <tr>
                            <td>Name</td>
                            <td>Count</td>
                        </tr>
                    </thead>
                    <tbody>

                        {medicineDemand.map(obj => (
                            <tr>
                                <td>
                                    <Form.Label htmlFor="Oxytocin">{obj.medicineName}</Form.Label>
                                </td>
                                <td>
                                    <Form.Control type={"number"} name={`${obj.medicineName}`} value={obj.count} onChange={(e) => handleChange(e)} />
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </Table>
                <Button variant="primary" type="submit">Submit</Button>
            </Form>
            {show ? (<>

                <Row className="mt-4">
                    <Col md={12}>
                        <Table striped bordered hover>
                            <thead>
                                <tr>
                                    <th>S.No</th>
                                    <th>Pharmacy Name</th>
                                    <th>Medicine Name</th>
                                    <th>Supply Count</th>
                                    
                                </tr>
                            </thead>
                            <tbody>
                                {pharmacyDetails.data && pharmacyDetails.data.map((data, index) => (
                                    <tr>
                                        <td>{index + 1}</td>
                                        <td>{data.pharmacyName}</td>
                                        <td>{data.medicineName}</td>
                                        <td>{data.supplyCount}</td>
                                        
                                    </tr>
                                ))}

                            </tbody>
                        </Table>
                    </Col>
                </Row>

            </>) : ""}
        </>
    )
}

export default Medicinedemand;