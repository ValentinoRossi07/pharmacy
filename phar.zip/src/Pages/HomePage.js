import React from "react";
import { Link, Navigate } from "react-router-dom";
import { Container, Row, Col } from "react-bootstrap";

import Homepagedata from "./Homepagedata";

export const Homepage = () => {

    if (localStorage.getItem("isLoggedIn") === "false") {
        return <Navigate to="/login" />;
    }

    return (
        <React.Fragment>
            <React.Fragment>
                <Container className="mt-3">
                    <Row>
                        <Homepagedata />
                    </Row>
                </Container>
            </React.Fragment>
        </React.Fragment>
    );
};
