import React from "react";
import { Navbar, Container, Nav , Button} from "react-bootstrap";
import { Link, useNavigate } from "react-router-dom";


export const NavbarPage = () => {
  const navigate = useNavigate();
  const handleClick = () => {
    localStorage.removeItem("access");
    localStorage.setItem("isLoggedIn", false);
    navigate("/login");
  };

  let name = "Login";

  if (localStorage.getItem("isLoggedIn")) {
    name = "Logout";
  }
  console.log(typeof localStorage.getItem("isLoggedIn"));

  return (
    <>
      <Navbar bg="primary" variant="dark">
        <Container>
          <Navbar.Brand as={Link} to="/" className="navbartitle">
          {/* <FontAwesomeIcon icon="fa-thin fa-prescription-bottle-medical" /> */}
            Pharmacy Medicine Management System
          </Navbar.Brand>
          <Nav className="ms-auto">
            {localStorage.getItem("isLoggedIn") === "true" ? (
              <>
                <Link className="text-white me-2" to="/">
                  <Button>Home</Button></Link>
                <a className="text-white" onClick={handleClick}>
                  <Button>Logout</Button></a>
              </>
            ) : (
             null
            )}
          </Nav>
        </Container>
      </Navbar>
    </>
  );
};
